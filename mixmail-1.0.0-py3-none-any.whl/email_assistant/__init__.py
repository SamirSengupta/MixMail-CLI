"""MixMail — OpenClaw-inspired tool-calling agent for Gmail."""

__version__ = "1.0.0"
