"""Module entrypoint for `python -m email_assistant`."""

from email_assistant.cli import main


if __name__ == "__main__":
    main()