"""
OpenClaw-inspired ReAct agent with Cerebras function-calling.

Implements a tool-calling loop:
  1. Send user query + tool schemas to the LLM.
  2. If the LLM returns tool_calls → execute each → feed results back.
  3. Repeat until the LLM produces a final text response.
"""

from __future__ import annotations

import json
from typing import Any

from cerebras.cloud.sdk import Cerebras

from email_assistant.config import get_settings
from email_assistant.tools import TOOL_SCHEMAS, execute_tool


class EmailAgent:
    """Autonomous email assistant agent with tool-calling capabilities."""

    MAX_ITERATIONS: int = 10  # Safety cap for the tool-calling loop

    def __init__(self) -> None:
        settings = get_settings()
        settings.validate()
        self._client = Cerebras(api_key=settings.cerebras_api_key)
        self._model = settings.llm_model
        self._conversation: list[dict[str, Any]] = [
            {"role": "system", "content": settings.system_prompt},
        ]

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def ask(self, user_input: str) -> str:
        """Process a natural-language query through the agent loop.

        The agent may call tools multiple times before producing a final
        answer.

        Args:
            user_input: The user's natural-language query.

        Returns:
            The agent's final text response.
        """
        self._conversation.append({"role": "user", "content": user_input})

        for _ in range(self.MAX_ITERATIONS):
            response_msg = self._chat_completion()

            # If the model wants to call tools, execute them
            tool_calls = getattr(response_msg, "tool_calls", None)
            if tool_calls:
                # Append the assistant message (with tool_calls) to history
                self._conversation.append(
                    self._serialise_assistant_message(response_msg)
                )

                for tool_call in tool_calls:
                    result = self._handle_tool_call(tool_call)
                    self._conversation.append(
                        {
                            "role": "tool",
                            "tool_call_id": tool_call.id,
                            "content": result,
                        }
                    )
                continue  # Let the model see the results and decide next step

            # No tool calls → final text answer
            answer = response_msg.content or ""
            self._conversation.append(
                {"role": "assistant", "content": answer}
            )
            return answer

        return (
            "I reached the maximum number of reasoning steps. "
            "Please try a more specific query."
        )

    def reset(self) -> None:
        """Clear conversation history (keep system prompt)."""
        self._conversation = [self._conversation[0]]

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _chat_completion(self) -> Any:
        """Call the Cerebras Chat Completions API with tools."""
        response = self._client.chat.completions.create(
            model=self._model,
            messages=self._conversation,  # type: ignore[arg-type]
            tools=TOOL_SCHEMAS,  # type: ignore[arg-type]
            tool_choice="auto",
            temperature=0.2,
        )
        return response.choices[0].message

    @staticmethod
    def _handle_tool_call(tool_call: Any) -> str:
        """Execute a single tool call and return the result as a string."""
        name = tool_call.function.name
        arguments = tool_call.function.arguments
        return execute_tool(name, arguments)

    @staticmethod
    def _serialise_assistant_message(msg: Any) -> dict[str, Any]:
        """Convert an assistant message object to a serialisable dict.

        Required because the conversation list stores plain dicts, not
        SDK objects.
        """
        serialised: dict[str, Any] = {
            "role": "assistant",
            "content": msg.content,
        }
        tool_calls = getattr(msg, "tool_calls", None)
        if tool_calls:
            serialised["tool_calls"] = [
                {
                    "id": tc.id,
                    "type": "function",
                    "function": {
                        "name": tc.function.name,
                        "arguments": tc.function.arguments,
                    },
                }
                for tc in tool_calls
            ]
        return serialised
