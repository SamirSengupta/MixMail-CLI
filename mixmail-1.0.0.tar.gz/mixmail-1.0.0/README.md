# 📧 MixMail

MixMail is an autonomous AI agent that connects to your Gmail inbox and lets you query emails using natural language. Powered by **Cerebras gpt-oss-120b** function-calling and the **Gmail API**.

## Architecture

```
User ──▶ mixmail CLI ──▶ Agent ──▶ LLM (Cerebras) ──▶ Tool Call ──▶ Gmail API
                                ▲                                │
                                └──── LLM Summary ◀── Results ◀──┘
```

## Project Structure

```
MixMail/
├── pyproject.toml              # Package metadata + CLI command
├── main.py                     # Backward-compatible launcher
├── requirements.txt            # Python dependencies
├── .env                        # API keys (create from .env.example)
├── .env.example                # Template
├── client_secret_*.json        # Google OAuth client secret
├── token.json                  # Auto-generated after first auth
├── README.md
└── email_assistant/
    ├── __init__.py
   ├── __main__.py             # Allows: python -m email_assistant
   ├── cli.py                  # CLI implementation
    ├── config.py               # Settings & env var loading
    ├── gmail_client.py         # Gmail API client (OAuth, search, read)
    ├── tools.py                # Agent tool definitions & schemas
    ├── summarizer.py           # LLM-powered email summarisation
    └── agent.py                # ReAct tool-calling agent loop
```

## Setup

### 1. Google Cloud Project

1. Go to [Google Cloud Console](https://console.cloud.google.com/).
2. Create a new project (or use an existing one).
3. Enable the **Gmail API**:
   - Navigate to **APIs & Services → Library**.
   - Search for "Gmail API" and click **Enable**.
4. Create OAuth 2.0 credentials:
   - Go to **APIs & Services → Credentials**.
   - Click **Create Credentials → OAuth client ID**.
   - Choose **Desktop app**.
   - Download the JSON file — this is your `credentials.json`.
5. Configure the OAuth consent screen:
   - Add your email as a **test user** (while the app is in testing mode).

> **Note:** Your credentials file is already in the project root. The `.env` is pre-configured to use it.

### 2. Install Dependencies

```bash
cd MicroClawd
pip install .
```

This installs the package and exposes the `mixmail` command globally in the active Python environment, the same way other Python CLIs are installed.

### 3. Configure Environment

For local development in the repo, edit `.env` and add your Cerebras API key:

```env
CEREBRAS_API_KEY=csk-your-actual-key-here
```

For an installed CLI, create a user config directory and put your config there instead:

```powershell
mkdir $HOME/.mixmail
```

Create `$HOME/.mixmail/.env` with:

```env
CEREBRAS_API_KEY=csk-your-actual-key-here
GMAIL_CREDENTIALS_PATH=client_secret.json
GMAIL_TOKEN_PATH=token.json
```

Then place your Google OAuth client secret JSON in `$HOME/.mixmail/client_secret.json`.

### 4. Run

```bash
mixmail
```

Alternative entrypoints if needed:

```bash
python -m email_assistant
python main.py
```

On first run, a browser window will open for Gmail OAuth consent. After authorizing, a `token.json` file is saved automatically — subsequent runs won't require re-auth.

When installed as a CLI, the token is stored in `$HOME/.mixmail/token.json` by default.

## Usage Examples

```
You ❯ find emails from recruiters last week

Agent:
Found 3 emails.

1. Amazon Recruiting
   Subject: ML Engineer role — Seattle
   Summary: Recruiter reaching out regarding an open ML position.

2. Deloitte Talent
   Subject: Interview scheduling
   Summary: Asking for availability for a technical interview.

3. Startup Founder
   Subject: AI Engineer opportunity
   Summary: Early-stage startup looking for founding engineer.
```

```
You ❯ show unread emails with attachments
You ❯ summarize the thread about visa sponsorship
You ❯ list job interview emails from this month
```

### Commands

| Command | Action |
|---------|--------|
| `help`  | Show usage tips |
| `reset` | Clear conversation history |
| `/api_key` | Save the Cerebras API key interactively |
| `/mail_creds` | Paste or import Google OAuth credentials |
| `/setup` | Show the active MixMail config locations |
| `quit`  | Exit the assistant |

For first-time setup in the installed CLI, you can now configure everything inside the app:

```text
mixmail
/api_key
/mail_creds
```

`/mail_creds` accepts either:

- A pasted Google OAuth desktop-app JSON document.
- A file path like `C:/Users/Alice/Downloads/client_secret.json`.
- A file import command like `file:C:/Users/Alice/Downloads/client_secret.json`.

## Features

- **Natural language search** — translates plain English into Gmail search syntax
- **Email retrieval** — fetches sender, subject, date, snippet, attachments
- **Full message reading** — retrieves complete email bodies on demand
- **Thread summarisation** — summarizes entire email conversations
- **Attachment detection** — lists filenames of attached documents
- **Email categorisation** — classifies emails (recruiters, finance, personal, promotions)
- **Pagination** — handles large result sets gracefully
- **Auto token refresh** — OAuth tokens are refreshed automatically

## Troubleshooting

| Issue | Fix |
|-------|-----|
| `CEREBRAS_API_KEY is not set` | Add your key to `.env` |
| `credentials file not found` | Ensure your OAuth JSON is in the project root |
| Browser doesn't open for auth | Run from a terminal with browser access |
| `403 Forbidden` on Gmail API | Enable Gmail API in Cloud Console; add yourself as a test user |
| Token expired | Delete `token.json` and re-run |

## Packaging For Clients

If you want a client to install and run this like a standard CLI:

```bash
pip install git+https://github.com/your-org/MixMail.git
mixmail
```

Each client machine still needs its own runtime config:

- A Cerebras API key in `$HOME/.mixmail/.env`, unless you provide your own backend.
- A Google OAuth client secret JSON file.
- First-run browser login to grant Gmail access.

Important: if the CLI runs on the client machine, the API key and Gmail OAuth flow also happen on that client machine. If you do not want to expose your API key or distribute Google credentials, the correct architecture is a hosted backend rather than a local CLI.

For local handoff, you can also build a wheel and share that instead of the source tree:

```bash
python -m pip install build
python -m build
pip install dist/mixmail-1.0.0-py3-none-any.whl
mixmail
```
