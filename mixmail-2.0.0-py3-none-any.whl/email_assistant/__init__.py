"""MixMail — a natural-language agent for your Gmail inbox."""

__version__ = "2.0.0"
