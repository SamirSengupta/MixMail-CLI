"""Tool-calling agent loop for MixMail.

The agent is fully LLM-driven: it sends the conversation plus the available
tool schemas to the model, executes whatever tools the model requests, feeds the
results back, and repeats until the model produces a final answer. Destructive
actions (send, reply, trash) are gated behind a confirmation callback so the CLI
can ask the user before anything irreversible happens.
"""

from __future__ import annotations

import json
from typing import Any, Callable

from email_assistant.config import Settings, get_settings
from email_assistant.tools import (
    CONFIRM_TOOLS,
    TOOL_SCHEMAS,
    describe_tool_call,
    execute_tool,
)

# (tool_name, human_description) -> bool. Return True to allow the action.
ConfirmCallback = Callable[[str, str], bool]


class EmailAgent:
    """Autonomous Gmail assistant driven by an LLM tool-calling loop."""

    MAX_ITERATIONS: int = 12

    def __init__(
        self,
        confirm_callback: ConfirmCallback | None = None,
        settings: Settings | None = None,
    ) -> None:
        settings = settings or get_settings()
        settings.validate()
        self._client = settings.llm_client()
        self._confirm: ConfirmCallback = confirm_callback or (lambda _n, _d: True)
        self._system: list[dict[str, Any]] = [
            {"role": "system", "content": settings.system_prompt},
            {
                "role": "system",
                "content": (
                    "Never fabricate email data — only report what tools return. "
                    "If a search is empty, say so. Never output placeholders like "
                    "[Insert Date] or [Insert Message ID]. When you have enough "
                    "information, give a clear final answer instead of calling more tools."
                ),
            },
        ]
        self._conversation: list[dict[str, Any]] = list(self._system)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    def ask(
        self,
        user_input: str,
        on_delta: Callable[[str], None] | None = None,
        on_tool: Callable[[str], None] | None = None,
    ) -> str:
        """Process a query, returning the final answer.

        If ``on_delta`` is provided, assistant text is streamed to it as it
        arrives (used by the CLI for live output). ``on_tool`` is called with
        each tool name just before it runs, for progress display.
        """
        self._conversation.append({"role": "user", "content": user_input})

        for _ in range(self.MAX_ITERATIONS):
            message = self._next_message(on_delta)
            tool_calls = message.get("tool_calls")

            if not tool_calls:
                answer = message.get("content", "") or ""
                self._conversation.append({"role": "assistant", "content": answer})
                return answer

            self._conversation.append(self._serialise_assistant(message))
            for tool_call in tool_calls:
                if on_tool is not None:
                    on_tool(tool_call["function"]["name"])
                self._conversation.append(self._run_tool_call(tool_call))

        fallback = (
            "I reached the maximum number of reasoning steps. "
            "Please try a more specific request."
        )
        self._conversation.append({"role": "assistant", "content": fallback})
        return fallback

    def reset(self) -> None:
        """Clear conversation history, keeping the system prompts."""
        self._conversation = list(self._system)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------
    def _next_message(self, on_delta: Callable[[str], None] | None) -> dict[str, Any]:
        if on_delta is None:
            return self._client.complete(self._conversation, TOOL_SCHEMAS)
        return self._client.stream_complete(
            self._conversation, TOOL_SCHEMAS, on_delta=on_delta
        )

    def _run_tool_call(self, tool_call: dict[str, Any]) -> dict[str, Any]:
        """Execute one tool call (with confirmation if required)."""
        function = tool_call["function"]
        name = function["name"]
        raw_arguments = function.get("arguments", "") or "{}"

        if name in CONFIRM_TOOLS:
            try:
                parsed = json.loads(raw_arguments) if raw_arguments.strip() else {}
            except json.JSONDecodeError:
                parsed = {}
            if not self._confirm(name, describe_tool_call(name, parsed)):
                result = json.dumps(
                    {"status": "cancelled", "detail": "The user declined this action."}
                )
                return self._tool_message(tool_call["id"], result)

        result = execute_tool(name, raw_arguments)
        return self._tool_message(tool_call["id"], result)

    @staticmethod
    def _tool_message(tool_call_id: str, content: str) -> dict[str, Any]:
        return {"role": "tool", "tool_call_id": tool_call_id, "content": content}

    @staticmethod
    def _serialise_assistant(message: dict[str, Any]) -> dict[str, Any]:
        serialised: dict[str, Any] = {
            "role": "assistant",
            "content": message.get("content"),
        }
        tool_calls = message.get("tool_calls")
        if tool_calls:
            serialised["tool_calls"] = [
                {
                    "id": tc["id"],
                    "type": "function",
                    "function": {
                        "name": tc["function"]["name"],
                        "arguments": tc["function"].get("arguments", ""),
                    },
                }
                for tc in tool_calls
            ]
        return serialised
