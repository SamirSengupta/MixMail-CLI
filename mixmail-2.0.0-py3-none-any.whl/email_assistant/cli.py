"""Interactive CLI for MixMail."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.text import Text

from email_assistant.agent import EmailAgent
from email_assistant.config import (
    get_settings,
    get_setup_paths,
    import_mail_credentials_file,
    save_gmail_scope_mode,
    save_llm_api_key,
    save_llm_base_url,
    save_llm_model,
    save_mail_credentials,
)
from email_assistant.tools import reset_client

console = Console()

BANNER = r"""
 MM    MM IIIII XX   XX MM    MM   AAA   IIIII LL
 MMM  MMM  III   XX XX  MMM  MMM  AAAAA   III  LL
 MM MM MM  III    XXX   MM MM MM AA   AA  III  LL
 MM    MM  III   XX XX  MM    MM AAAAAAA  III  LL
 MM    MM IIIII XX   XX MM    MM AA   AA IIIII LLLLLLL
            MIXMAIL - your Gmail, in plain English
"""

HELP_TEXT = """\
## How to use

Type any natural-language request about your email. Examples:

- `find emails from recruiters last week`
- `show unread emails with attachments`
- `summarize the latest thread from Amazon`
- `draft a reply to the visa sponsorship email saying I'm interested`
- `archive all promotions from this month`
- `mark the newsletter from Stripe as read`

### Commands
| Command | Action |
|---------|--------|
| `help` | Show this help |
| `reset` | Clear conversation history |
| `/wizard` | Run the guided setup again |
| `/llm_url` | Set the LLM server URL |
| `/model` | Set the model name |
| `/api_key` | Set an API key (hosted providers) |
| `/mail_creds` | Paste or import Google OAuth JSON |
| `/scope` | Choose `readonly` or `full` Gmail access |
| `/setup` | Show current config locations |
| `quit` / `exit` | Leave MixMail |
"""

_TOOL_LABELS = {
    "search_emails": "Searching Gmail",
    "get_email": "Reading message",
    "get_thread": "Reading thread",
    "list_labels": "Fetching labels",
    "send_email": "Sending email",
    "create_draft": "Saving draft",
    "reply": "Sending reply",
    "mark_read": "Updating read state",
    "star_email": "Updating star",
    "archive_email": "Archiving",
    "trash_email": "Moving to Trash",
    "download_attachment": "Downloading attachment",
}


# ---------------------------------------------------------------------------
# Display helpers
# ---------------------------------------------------------------------------
def print_banner() -> None:
    console.print(
        Panel(
            Text(BANNER, style="bold cyan"),
            border_style="bright_blue",
            subtitle="[dim]help . /setup . quit[/dim]",
        )
    )


def _looks_like_credentials_path(value: str) -> bool:
    if not value:
        return False
    candidate = value[5:].strip() if value.lower().startswith("file:") else value
    return candidate.lower().endswith(".json") and Path(candidate).expanduser().exists()


def make_confirm_callback():
    """Build a confirmation callback that previews destructive actions."""

    def confirm(name: str, description: str) -> bool:
        title = {"send_email": "Send this email?", "reply": "Send this reply?",
                 "trash_email": "Move to Trash?"}.get(name, "Confirm action?")
        console.print()
        console.print(Panel(description, title=f"[bold yellow]{title}[/]",
                            border_style="yellow", padding=(1, 2)))
        answer = console.input("[bold yellow]Proceed? [y/N] >[/] ").strip().lower()
        return answer in {"y", "yes"}

    return confirm


# ---------------------------------------------------------------------------
# Agent lifecycle
# ---------------------------------------------------------------------------
def create_agent() -> EmailAgent | None:
    try:
        return EmailAgent(confirm_callback=make_confirm_callback())
    except ValueError as exc:
        console.print(f"\n[bold red]Configuration needed:[/] {exc}")
        console.print(
            "\n[dim]Run [cyan]/wizard[/cyan] for guided setup, or use "
            "[cyan]/mail_creds[/cyan] and [cyan]/llm_url[/cyan].[/dim]\n"
        )
        return None


def reload_agent(after: str) -> EmailAgent | None:
    """Rebuild the agent and Gmail client after a config change."""
    reset_client()
    agent = create_agent()
    if agent is not None:
        console.print(f"[bold green]OK[/] {after}\n")
    return agent


# ---------------------------------------------------------------------------
# Setup / command handlers
# ---------------------------------------------------------------------------
def run_setup_wizard() -> None:
    """Guided first-run configuration."""
    console.print(Panel("[bold]Welcome to MixMail setup[/]\n\n"
                        "Let's connect a language model and your Gmail account. "
                        "Press Enter to accept the default in [dim]brackets[/dim].",
                        border_style="cyan"))

    settings = get_settings()
    url = console.input(f"[bold blue]LLM server URL[/] [dim][{settings.llm_base_url}][/dim] > ").strip()
    if url:
        try:
            save_llm_base_url(url)
        except ValueError as exc:
            console.print(f"[red]{exc}[/] (keeping previous)")

    model = console.input(f"[bold blue]Model name[/] [dim][{settings.llm_model}][/dim] > ").strip()
    if model:
        save_llm_model(model)

    api_key = console.input("[bold blue]API key[/] [dim](blank for local servers)[/dim] > ").strip()
    if api_key:
        save_llm_api_key(api_key)

    if not get_settings().gmail_credentials_path.exists():
        console.print(Markdown(
            "Now your **Google OAuth client secret** (Desktop app JSON). "
            "Paste a file path, or `file:/path/to/client_secret.json`."
        ))
        creds = console.input("[bold blue]Credentials path[/] > ").strip()
        if creds and _looks_like_credentials_path(creds):
            src = creds[5:].strip() if creds.lower().startswith("file:") else creds
            try:
                dest = import_mail_credentials_file(src)
                console.print(f"[green]Imported credentials -> {dest}[/]")
            except FileNotFoundError as exc:
                console.print(f"[red]{exc}[/]")
        elif creds:
            console.print("[yellow]That path didn't resolve. Use /mail_creds later.[/]")

    scope = console.input("[bold blue]Gmail access[/] [dim][readonly]/full[/dim] > ").strip().lower()
    if scope in {"readonly", "full"}:
        save_gmail_scope_mode(scope)

    console.print("\n[bold green]Setup complete.[/] Re-run it anytime with /wizard.\n")


def handle_llm_url_command() -> None:
    url = console.input("[bold blue]LLM URL >[/] ").strip()
    if not url or url.lower() == "cancel":
        console.print("[dim]Cancelled.[/dim]\n")
        return
    try:
        save_llm_base_url(url)
    except ValueError as exc:
        console.print(f"[bold red]Error:[/] {exc}\n")


def handle_model_command() -> None:
    model = console.input("[bold blue]Model >[/] ").strip()
    if not model or model.lower() == "cancel":
        console.print("[dim]Cancelled.[/dim]\n")
        return
    save_llm_model(model)


def handle_api_key_command() -> None:
    key = console.input("[bold blue]API key (blank clears) >[/] ").strip()
    if key.lower() == "cancel":
        console.print("[dim]Cancelled.[/dim]\n")
        return
    save_llm_api_key(key)


def handle_scope_command() -> None:
    console.print(Markdown(
        "Choose Gmail access level:\n\n"
        "- `readonly` - search and read only (safest)\n"
        "- `full` - also send, reply, draft, label, archive, trash\n\n"
        "Changing this requires re-authenticating (delete the token shown in /setup)."
    ))
    mode = console.input("[bold blue]Scope [readonly/full] >[/] ").strip().lower()
    if mode not in {"readonly", "full"}:
        console.print("[dim]Cancelled.[/dim]\n")
        return
    save_gmail_scope_mode(mode)


def handle_mail_creds_command() -> None:
    console.print(Markdown(
        "Paste the Google OAuth desktop-app JSON, then a blank line to save. "
        "Or paste a file path, or `file:/path/to/client_secret.json`, or `cancel`."
    ))
    first = console.input("[bold blue]mail_creds >[/] ").strip()
    if not first or first.lower() == "cancel":
        console.print("[dim]Cancelled.[/dim]\n")
        return

    if _looks_like_credentials_path(first):
        src = first[5:].strip() if first.lower().startswith("file:") else first
        try:
            dest = import_mail_credentials_file(src)
        except FileNotFoundError as exc:
            console.print(f"[bold red]Error:[/] {exc}\n")
            return
        console.print(f"[bold green]Imported Gmail credentials -> {dest}[/]\n")
        return

    lines = [first]
    while True:
        nxt = console.input("[bold blue]...[/] ")
        if not nxt.strip():
            break
        lines.append(nxt)
    text = "\n".join(lines)
    try:
        json.loads(text)
    except json.JSONDecodeError as exc:
        console.print(f"[bold red]Invalid JSON:[/] {exc}\n")
        return
    dest = save_mail_credentials(text)
    console.print(f"[bold green]Saved Gmail credentials -> {dest}[/]\n")


def handle_setup_command() -> None:
    p = get_setup_paths()
    api = "set" if p["llm_api_key_set"] else "[dim]not set[/dim]"
    message = (
        f"[bold]Config home:[/] [cyan]{p['app_home']}[/cyan]\n"
        f"[bold]Env file:[/] [cyan]{p['env_path']}[/cyan]\n"
        f"[bold]LLM URL:[/] [cyan]{p['llm_base_url']}[/cyan]\n"
        f"[bold]Model:[/] [cyan]{p['llm_model']}[/cyan]\n"
        f"[bold]API key:[/] {api}\n"
        f"[bold]Gmail access:[/] [cyan]{p['gmail_scope_mode']}[/cyan]\n"
        f"[bold]Credentials:[/] [cyan]{p['credentials_path']}[/cyan]\n"
        f"[bold]OAuth token:[/] [cyan]{p['token_path']}[/cyan]"
    )
    console.print(Panel(message, border_style="blue", title="Setup"))
    console.print()


# ---------------------------------------------------------------------------
# Query handling
# ---------------------------------------------------------------------------
def run_query(agent: EmailAgent, user_input: str) -> None:
    """Send a query to the agent and stream the response."""
    state = {"streamed": False}

    def on_delta(chunk: str) -> None:
        if not state["streamed"]:
            console.print("\n[bold green]MixMail[/] [dim]>[/]")
            state["streamed"] = True
        sys.stdout.write(chunk)
        sys.stdout.flush()

    def on_tool(name: str) -> None:
        console.print(f"[dim]. {_TOOL_LABELS.get(name, name)}...[/dim]")

    try:
        answer = agent.ask(user_input, on_delta=on_delta, on_tool=on_tool)
    except Exception as exc:  # noqa: BLE001
        console.print(f"\n[bold red]Error:[/] {exc}\n")
        return

    if state["streamed"]:
        console.print("\n")
    else:
        console.print(Panel(Markdown(answer or "[no response]"),
                            border_style="green", title="[bold green]MixMail[/]",
                            title_align="left", padding=(1, 2)))
        console.print()


# ---------------------------------------------------------------------------
# Main loop
# ---------------------------------------------------------------------------
COMMANDS = {
    "/wizard": run_setup_wizard,
    "/llm_url": handle_llm_url_command,
    "/model": handle_model_command,
    "/api_key": handle_api_key_command,
    "/mail_creds": handle_mail_creds_command,
    "/scope": handle_scope_command,
    "/setup": handle_setup_command,
}
_RELOAD_AFTER = {
    "/wizard": "Setup saved - MixMail is ready.",
    "/llm_url": "LLM URL updated.",
    "/model": "Model updated.",
    "/api_key": "API key updated.",
    "/mail_creds": "Gmail credentials updated.",
    "/scope": "Gmail access level updated.",
}


def main() -> None:
    print_banner()

    if not get_settings().gmail_credentials_path.exists():
        run_setup_wizard()

    agent = create_agent()
    if agent is not None:
        console.print("[bold green]OK[/] MixMail is ready.\n")

    while True:
        try:
            user_input = console.input("[bold blue]You >[/] ").strip()
        except (EOFError, KeyboardInterrupt):
            console.print("\n[dim]Goodbye![/dim]")
            break

        if not user_input:
            continue
        lower = user_input.lower()

        if lower in {"quit", "exit", "q"}:
            console.print("[dim]Goodbye![/dim]")
            break
        if lower == "help":
            console.print(Markdown(HELP_TEXT))
            continue
        if lower == "reset":
            if agent is None:
                console.print("[dim]MixMail is not configured yet.[/dim]\n")
            else:
                agent.reset()
                console.print("[dim]Conversation history cleared.[/dim]\n")
            continue
        if lower in COMMANDS:
            COMMANDS[lower]()
            if lower in _RELOAD_AFTER:
                agent = reload_agent(_RELOAD_AFTER[lower])
            continue
        if lower.startswith("/"):
            console.print("[bold yellow]Unknown command.[/] Type [cyan]help[/cyan].\n")
            continue

        if agent is None:
            console.print("[dim]Finish setup with [cyan]/wizard[/cyan] first.[/dim]\n")
            continue

        run_query(agent, user_input)


if __name__ == "__main__":
    main()
