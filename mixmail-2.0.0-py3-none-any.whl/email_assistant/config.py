"""Configuration for MixMail.

Loads settings from environment / ``.env`` files and resolves the locations of
Gmail credentials and tokens for both local development and installed-CLI use.
"""

from __future__ import annotations

import os
import shutil
from dataclasses import dataclass, field
from pathlib import Path

from dotenv import load_dotenv

from email_assistant.llm import LLMClient

_PACKAGE_ROOT = Path(__file__).resolve().parent.parent
_APP_HOME = Path(
    os.getenv("MIXMAIL_HOME", str(Path.home() / ".mixmail"))
).expanduser()
_DEFAULT_CREDENTIALS_FILENAME = "client_secret.json"
_DEFAULT_TOKEN_FILENAME = "token.json"

# Gmail OAuth scope presets. ``readonly`` is the safe default; ``full`` unlocks
# sending, drafts, labels, archiving and trashing.
GMAIL_SCOPE_PRESETS: dict[str, list[str]] = {
    "readonly": ["https://www.googleapis.com/auth/gmail.readonly"],
    "full": [
        "https://www.googleapis.com/auth/gmail.modify",
        "https://www.googleapis.com/auth/gmail.compose",
        "https://www.googleapis.com/auth/gmail.send",
    ],
}


def _load_env_files() -> None:
    """Load ``.env`` files from preferred config locations (earliest wins)."""
    for candidate in (
        Path.cwd() / ".env",
        _APP_HOME / ".env",
        _PACKAGE_ROOT / ".env",
    ):
        if candidate.exists():
            load_dotenv(candidate)


def _resolve_env_path() -> Path:
    """Return the preferred writable ``.env`` path."""
    cwd_env = Path.cwd() / ".env"
    if cwd_env.exists():
        return cwd_env
    return _APP_HOME / ".env"


def _resolve_config_path(path_value: str, *, must_exist: bool) -> Path:
    """Resolve a config file location for both dev and installed-CLI usage."""
    raw_path = Path(path_value).expanduser()
    if raw_path.is_absolute():
        return raw_path

    candidates = [
        Path.cwd() / raw_path,
        _APP_HOME / raw_path,
        _PACKAGE_ROOT / raw_path,
    ]
    if must_exist:
        for candidate in candidates:
            if candidate.exists():
                return candidate
    return _APP_HOME / raw_path


_load_env_files()


_DEFAULT_SYSTEM_PROMPT = (
    "You are MixMail, an intelligent Gmail assistant. You help the user search, "
    "read, organise, draft, and send email using natural language. Translate "
    "requests into Gmail search syntax (operators like from:, to:, subject:, "
    "newer_than:Nd, older_than:Nd, is:unread, has:attachment, label:, in:sent) "
    "and call the provided tools to act on real data. Present results clearly: a "
    "numbered list with sender, subject, date, and a short summary; for a single "
    "thread, give a concise recap with key decisions and action items. Note "
    "attachments when present. Never invent emails, message IDs, or dates — only "
    "report what tools return, and if a search is empty, say so plainly. Only "
    "send mail, modify, archive, or trash when the user clearly asks; for sending, "
    "make sure the recipient, subject, and body are all known before calling the tool."
)


@dataclass(frozen=True)
class Settings:
    """Immutable application-wide settings loaded from the environment."""

    # --- LLM ------------------------------------------------------------
    llm_base_url: str = field(
        default_factory=lambda: os.getenv(
            "LLM_BASE_URL", "http://localhost:1200/v1"
        ).rstrip("/")
    )
    llm_model: str = field(
        default_factory=lambda: os.getenv("LLM_MODEL", "qwen2.5-coder-1.5b-instruct")
    )
    llm_api_key: str = field(default_factory=lambda: os.getenv("LLM_API_KEY", ""))

    # --- Gmail ----------------------------------------------------------
    gmail_credentials_path: Path = field(
        default_factory=lambda: _resolve_config_path(
            os.getenv("GMAIL_CREDENTIALS_PATH", _DEFAULT_CREDENTIALS_FILENAME),
            must_exist=True,
        )
    )
    gmail_token_path: Path = field(
        default_factory=lambda: _resolve_config_path(
            os.getenv("GMAIL_TOKEN_PATH", _DEFAULT_TOKEN_FILENAME),
            must_exist=False,
        )
    )
    gmail_scope_mode: str = field(
        default_factory=lambda: os.getenv("GMAIL_SCOPE_MODE", "readonly").strip().lower()
    )

    # --- Behaviour ------------------------------------------------------
    max_results: int = field(
        default_factory=lambda: int(os.getenv("MAX_RESULTS", "10"))
    )
    system_prompt: str = field(
        default_factory=lambda: os.getenv("SYSTEM_PROMPT", _DEFAULT_SYSTEM_PROMPT)
    )

    @property
    def gmail_scopes(self) -> list[str]:
        """OAuth scopes for the configured mode (defaults to read-only)."""
        return GMAIL_SCOPE_PRESETS.get(
            self.gmail_scope_mode, GMAIL_SCOPE_PRESETS["readonly"]
        )

    @property
    def can_write(self) -> bool:
        """True when the configured scope mode allows mutating actions."""
        return self.gmail_scope_mode == "full"

    def llm_client(self) -> LLMClient:
        """Build an :class:`LLMClient` from these settings."""
        return LLMClient(
            base_url=self.llm_base_url,
            model=self.llm_model,
            api_key=self.llm_api_key,
        )

    def validate(self) -> None:
        """Raise ``ValueError`` if critical settings are missing."""
        if not self.gmail_credentials_path.exists():
            raise ValueError(
                f"Gmail credentials file not found at {self.gmail_credentials_path}. "
                f"Download an OAuth desktop-app client secret from the Google Cloud "
                f"Console and import it with /mail_creds, or place it in {_APP_HOME}."
            )


def get_settings() -> Settings:
    """Return a fresh settings snapshot from the current environment."""
    _load_env_files()
    return Settings()


# ---------------------------------------------------------------------------
# Mutation helpers (write to the active .env)
# ---------------------------------------------------------------------------
def _ensure_parent_dir(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)


def _write_env_values(updates: dict[str, str]) -> Path:
    """Upsert ``KEY=value`` pairs into the active ``.env`` and ``os.environ``."""
    env_path = _resolve_env_path()
    _ensure_parent_dir(env_path)

    lines = env_path.read_text(encoding="utf-8").splitlines() if env_path.exists() else []
    seen: set[str] = set()
    new_lines: list[str] = []
    for line in lines:
        replaced = False
        for key, value in updates.items():
            if line.startswith(f"{key}="):
                new_lines.append(f"{key}={value}")
                seen.add(key)
                replaced = True
                break
        if not replaced:
            new_lines.append(line)

    for key, value in updates.items():
        if key not in seen:
            if new_lines and new_lines[-1].strip():
                new_lines.append("")
            new_lines.append(f"{key}={value}")

    env_path.write_text("\n".join(new_lines) + "\n", encoding="utf-8")
    os.environ.update(updates)
    return env_path


def _normalise_llm_base_url(base_url: str) -> str:
    """Normalise user-provided OpenAI-compatible base URLs."""
    cleaned = base_url.strip().rstrip("/")
    if not cleaned.lower().startswith(("http://", "https://")):
        raise ValueError("LLM URL must start with http:// or https://.")
    if cleaned.lower().endswith("/chat/completions"):
        cleaned = cleaned[: -len("/chat/completions")]
    if "/chat/" in cleaned.lower():
        raise ValueError(
            "Use the base URL (for example http://localhost:1200/v1), "
            "not a nested /chat/* path."
        )
    if not cleaned:
        raise ValueError("LLM URL cannot be empty.")
    return cleaned


def save_llm_base_url(base_url: str) -> Path:
    """Persist the LLM base URL to the active ``.env``."""
    return _write_env_values({"LLM_BASE_URL": _normalise_llm_base_url(base_url)})


def save_llm_model(model: str) -> Path:
    """Persist the LLM model name."""
    model = model.strip()
    if not model:
        raise ValueError("Model name cannot be empty.")
    return _write_env_values({"LLM_MODEL": model})


def save_llm_api_key(api_key: str) -> Path:
    """Persist the LLM API key (for hosted OpenAI-compatible providers)."""
    return _write_env_values({"LLM_API_KEY": api_key.strip()})


def save_gmail_scope_mode(mode: str) -> Path:
    """Persist the Gmail scope mode (``readonly`` or ``full``)."""
    mode = mode.strip().lower()
    if mode not in GMAIL_SCOPE_PRESETS:
        raise ValueError("Scope mode must be 'readonly' or 'full'.")
    return _write_env_values({"GMAIL_SCOPE_MODE": mode})


def save_mail_credentials(credentials_text: str) -> Path:
    """Persist pasted Google OAuth credentials JSON to the config location."""
    destination = _APP_HOME / _DEFAULT_CREDENTIALS_FILENAME
    _ensure_parent_dir(destination)
    destination.write_text(credentials_text.strip() + "\n", encoding="utf-8")
    _write_env_values(
        {
            "GMAIL_CREDENTIALS_PATH": _DEFAULT_CREDENTIALS_FILENAME,
            "GMAIL_TOKEN_PATH": _DEFAULT_TOKEN_FILENAME,
        }
    )
    return destination


def import_mail_credentials_file(source_path: str) -> Path:
    """Copy a Google OAuth credentials file into the MixMail config area."""
    source = Path(source_path).expanduser()
    if not source.exists():
        raise FileNotFoundError(f"File not found: {source}")
    destination = _APP_HOME / _DEFAULT_CREDENTIALS_FILENAME
    _ensure_parent_dir(destination)
    shutil.copyfile(source, destination)
    _write_env_values(
        {
            "GMAIL_CREDENTIALS_PATH": _DEFAULT_CREDENTIALS_FILENAME,
            "GMAIL_TOKEN_PATH": _DEFAULT_TOKEN_FILENAME,
        }
    )
    return destination


def get_setup_paths() -> dict[str, object]:
    """Return the main config values MixMail uses for setup."""
    settings = get_settings()
    return {
        "app_home": _APP_HOME,
        "env_path": _resolve_env_path(),
        "llm_base_url": settings.llm_base_url,
        "llm_model": settings.llm_model,
        "llm_api_key_set": bool(settings.llm_api_key),
        "gmail_scope_mode": settings.gmail_scope_mode,
        "credentials_path": settings.gmail_credentials_path,
        "token_path": settings.gmail_token_path,
    }
