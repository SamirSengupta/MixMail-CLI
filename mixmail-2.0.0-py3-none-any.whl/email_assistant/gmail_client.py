"""Gmail API client.

Handles OAuth 2.0 (with automatic token refresh and scope upgrades) and
provides high-level methods for searching, reading, threading, drafting,
sending, replying, labelling, archiving, trashing, and downloading
attachments.
"""

from __future__ import annotations

import base64
import re
from email.message import EmailMessage
from email.utils import parsedate_to_datetime
from pathlib import Path
from typing import Any

from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import Resource, build

from email_assistant.config import get_settings

_SEND_SCOPE = "https://www.googleapis.com/auth/gmail.send"
_MODIFY_SCOPE = "https://www.googleapis.com/auth/gmail.modify"
_COMPOSE_SCOPE = "https://www.googleapis.com/auth/gmail.compose"


class ScopeError(RuntimeError):
    """Raised when the current token lacks a scope needed for an action."""


class GmailClient:
    """Wrapper around the Gmail API with auto-refreshing OAuth tokens."""

    def __init__(
        self,
        credentials_path: Path | None = None,
        token_path: Path | None = None,
        scopes: list[str] | None = None,
    ) -> None:
        settings = get_settings()
        self._credentials_path = credentials_path or settings.gmail_credentials_path
        self._token_path = token_path or settings.gmail_token_path
        self._scopes = scopes or settings.gmail_scopes
        self._service: Resource | None = None
        self._creds: Credentials | None = None

    # ------------------------------------------------------------------
    # Authentication
    # ------------------------------------------------------------------
    def _authenticate(self) -> Credentials:
        """Load or create OAuth credentials, refreshing/upgrading as needed."""
        creds: Credentials | None = None

        if self._token_path.exists():
            creds = Credentials.from_authorized_user_file(
                str(self._token_path), self._scopes
            )
            if not creds.has_scopes(self._scopes):
                creds = None

        if not creds or not creds.valid:
            if creds and creds.expired and creds.refresh_token:
                try:
                    creds.refresh(Request())
                except Exception:
                    creds = None
            if creds is None or not creds.valid:
                flow = InstalledAppFlow.from_client_secrets_file(
                    str(self._credentials_path), self._scopes
                )
                creds = flow.run_local_server(port=0)
            self._token_path.parent.mkdir(parents=True, exist_ok=True)
            self._token_path.write_text(creds.to_json())

        return creds

    @property
    def service(self) -> Resource:
        """Lazily initialised Gmail API service."""
        if self._service is None:
            self._creds = self._authenticate()
            self._service = build("gmail", "v1", credentials=self._creds)
        return self._service

    def _require_scope(self, scope: str, action: str) -> None:
        """Raise :class:`ScopeError` if the active token lacks ``scope``."""
        _ = self.service
        if self._creds is None or not self._creds.has_scopes([scope]):
            raise ScopeError(
                f"{action} needs additional Gmail permission. Run /scope full, "
                f"delete the token shown in /setup, restart MixMail, and sign in again."
            )

    # ------------------------------------------------------------------
    # Reading
    # ------------------------------------------------------------------
    def search_messages(
        self, query: str, max_results: int | None = None
    ) -> list[dict[str, Any]]:
        """Search Gmail and return lightweight metadata for each hit."""
        max_results = max_results or get_settings().max_results
        results: list[dict[str, Any]] = []
        page_token: str | None = None

        while len(results) < max_results:
            batch_size = min(max_results - len(results), 100)
            response = (
                self.service.users()
                .messages()
                .list(userId="me", q=query, maxResults=batch_size, pageToken=page_token)
                .execute()
            )
            messages = response.get("messages", [])
            if not messages:
                break
            for stub in messages:
                meta = self.get_message_metadata(stub["id"])
                if meta:
                    results.append(meta)
                if len(results) >= max_results:
                    break
            page_token = response.get("nextPageToken")
            if not page_token:
                break

        return results

    def get_message_metadata(self, message_id: str) -> dict[str, Any] | None:
        """Fetch a single message's metadata (headers + snippet)."""
        try:
            msg = (
                self.service.users()
                .messages()
                .get(userId="me", id=message_id, format="metadata")
                .execute()
            )
            return self._parse_message(msg)
        except Exception as exc:  # noqa: BLE001
            print(f"[warn] Failed to fetch message {message_id}: {exc}")
            return None

    def get_message_full(self, message_id: str) -> dict[str, Any] | None:
        """Fetch a message with its full body and attachment descriptors."""
        try:
            msg = (
                self.service.users()
                .messages()
                .get(userId="me", id=message_id, format="full")
                .execute()
            )
            parsed = self._parse_message(msg)
            payload = msg.get("payload", {})
            parsed["body"] = self._extract_body(payload)
            parsed["attachments"] = self._extract_attachments(payload)
            return parsed
        except Exception as exc:  # noqa: BLE001
            print(f"[warn] Failed to fetch full message {message_id}: {exc}")
            return None

    def get_thread(self, thread_id: str) -> list[dict[str, Any]]:
        """Fetch all messages in a thread, ordered chronologically."""
        try:
            thread = (
                self.service.users()
                .threads()
                .get(userId="me", id=thread_id, format="full")
                .execute()
            )
            messages = []
            for msg in thread.get("messages", []):
                parsed = self._parse_message(msg)
                parsed["body"] = self._extract_body(msg.get("payload", {}))
                messages.append(parsed)
            return messages
        except Exception as exc:  # noqa: BLE001
            print(f"[warn] Failed to fetch thread {thread_id}: {exc}")
            return []

    def list_labels(self) -> list[dict[str, str]]:
        """Return the user's Gmail labels (id + name)."""
        response = self.service.users().labels().list(userId="me").execute()
        return [
            {"id": label["id"], "name": label["name"]}
            for label in response.get("labels", [])
        ]

    # ------------------------------------------------------------------
    # Composing / sending
    # ------------------------------------------------------------------
    def send_message(
        self, to: str, subject: str, body: str, cc: str = "", bcc: str = ""
    ) -> dict[str, Any]:
        """Send an email from the authenticated account."""
        self._require_scope(_SEND_SCOPE, "Sending email")
        raw = self._build_raw(to, subject, body, cc, bcc)
        sent = (
            self.service.users()
            .messages()
            .send(userId="me", body={"raw": raw})
            .execute()
        )
        return {"status": "sent", "message_id": sent.get("id", ""),
                "thread_id": sent.get("threadId", ""), "to": to, "subject": subject}

    def create_draft(
        self, to: str, subject: str, body: str, cc: str = "", bcc: str = ""
    ) -> dict[str, Any]:
        """Create a draft email without sending it."""
        self._require_scope(_COMPOSE_SCOPE, "Creating a draft")
        raw = self._build_raw(to, subject, body, cc, bcc)
        draft = (
            self.service.users()
            .drafts()
            .create(userId="me", body={"message": {"raw": raw}})
            .execute()
        )
        return {"status": "draft_created", "draft_id": draft.get("id", ""),
                "to": to, "subject": subject}

    def reply(self, message_id: str, body: str, reply_all: bool = False) -> dict[str, Any]:
        """Reply to a message, preserving threading headers."""
        self._require_scope(_SEND_SCOPE, "Replying")
        original = (
            self.service.users()
            .messages()
            .get(userId="me", id=message_id, format="metadata",
                 metadataHeaders=["From", "To", "Cc", "Subject", "Message-ID", "References"])
            .execute()
        )
        headers = original.get("payload", {}).get("headers", [])
        sender = self._header(headers, "From")
        subject = self._header(headers, "Subject")
        msg_id_header = self._header(headers, "Message-ID")
        references = self._header(headers, "References")
        if not subject.lower().startswith("re:"):
            subject = f"Re: {subject}"

        recipients = sender
        cc = ""
        if reply_all:
            extra = [self._header(headers, "To"), self._header(headers, "Cc")]
            cc = ", ".join(part for part in extra if part)

        message = EmailMessage()
        message["To"] = recipients
        if cc:
            message["Cc"] = cc
        message["Subject"] = subject
        if msg_id_header:
            message["In-Reply-To"] = msg_id_header
            message["References"] = f"{references} {msg_id_header}".strip()
        message.set_content(body)
        raw = base64.urlsafe_b64encode(message.as_bytes()).decode("utf-8")

        sent = (
            self.service.users()
            .messages()
            .send(userId="me", body={"raw": raw, "threadId": original.get("threadId")})
            .execute()
        )
        return {"status": "sent", "message_id": sent.get("id", ""),
                "thread_id": sent.get("threadId", ""), "to": recipients, "subject": subject}

    # ------------------------------------------------------------------
    # Modifying
    # ------------------------------------------------------------------
    def modify_labels(
        self,
        message_id: str,
        add: list[str] | None = None,
        remove: list[str] | None = None,
    ) -> dict[str, Any]:
        """Add/remove labels on a message (low-level)."""
        self._require_scope(_MODIFY_SCOPE, "Modifying labels")
        self.service.users().messages().modify(
            userId="me",
            id=message_id,
            body={"addLabelIds": add or [], "removeLabelIds": remove or []},
        ).execute()
        return {"status": "modified", "message_id": message_id,
                "added": add or [], "removed": remove or []}

    def mark_read(self, message_id: str, read: bool = True) -> dict[str, Any]:
        """Mark a message read (default) or unread."""
        if read:
            return self.modify_labels(message_id, remove=["UNREAD"])
        return self.modify_labels(message_id, add=["UNREAD"])

    def set_starred(self, message_id: str, starred: bool = True) -> dict[str, Any]:
        """Star or unstar a message."""
        if starred:
            return self.modify_labels(message_id, add=["STARRED"])
        return self.modify_labels(message_id, remove=["STARRED"])

    def archive(self, message_id: str) -> dict[str, Any]:
        """Archive a message (remove it from the inbox)."""
        return self.modify_labels(message_id, remove=["INBOX"])

    def trash(self, message_id: str) -> dict[str, Any]:
        """Move a message to Trash (reversible for ~30 days)."""
        self._require_scope(_MODIFY_SCOPE, "Trashing")
        self.service.users().messages().trash(userId="me", id=message_id).execute()
        return {"status": "trashed", "message_id": message_id}

    # ------------------------------------------------------------------
    # Attachments
    # ------------------------------------------------------------------
    def download_attachment(
        self, message_id: str, filename: str, save_dir: str | Path
    ) -> dict[str, Any]:
        """Download a named attachment from a message to ``save_dir``."""
        full = (
            self.service.users()
            .messages()
            .get(userId="me", id=message_id, format="full")
            .execute()
        )
        target = None
        for part in self._iter_parts(full.get("payload", {})):
            if part.get("filename") == filename:
                target = part
                break
        if target is None:
            return {"error": f"No attachment named '{filename}' on this message."}

        body = target.get("body", {})
        data = body.get("data")
        if not data and body.get("attachmentId"):
            attachment = (
                self.service.users()
                .messages()
                .attachments()
                .get(userId="me", messageId=message_id, id=body["attachmentId"])
                .execute()
            )
            data = attachment.get("data")
        if not data:
            return {"error": "Attachment had no downloadable data."}

        save_dir = Path(save_dir).expanduser()
        save_dir.mkdir(parents=True, exist_ok=True)
        destination = save_dir / filename
        destination.write_bytes(base64.urlsafe_b64decode(data))
        return {"status": "downloaded", "filename": filename, "path": str(destination)}

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------
    @staticmethod
    def _build_raw(to: str, subject: str, body: str, cc: str, bcc: str) -> str:
        message = EmailMessage()
        message["To"] = to
        message["Subject"] = subject
        if cc:
            message["Cc"] = cc
        if bcc:
            message["Bcc"] = bcc
        message.set_content(body)
        return base64.urlsafe_b64encode(message.as_bytes()).decode("utf-8")

    @staticmethod
    def _header(headers: list[dict], name: str) -> str:
        for h in headers:
            if h["name"].lower() == name.lower():
                return h["value"]
        return ""

    def _parse_message(self, msg: dict[str, Any]) -> dict[str, Any]:
        headers = msg.get("payload", {}).get("headers", [])
        date_str = self._header(headers, "Date")
        try:
            formatted_date = parsedate_to_datetime(date_str).strftime("%Y-%m-%d %H:%M")
        except Exception:
            formatted_date = date_str

        attachment_names = [
            p.get("filename")
            for p in self._iter_parts(msg.get("payload", {}))
            if p.get("filename")
        ]
        return {
            "message_id": msg["id"],
            "thread_id": msg.get("threadId", ""),
            "sender": self._header(headers, "From"),
            "to": self._header(headers, "To"),
            "subject": self._header(headers, "Subject"),
            "date": formatted_date,
            "snippet": msg.get("snippet", ""),
            "has_attachments": bool(attachment_names),
            "attachment_names": attachment_names,
            "labels": msg.get("labelIds", []),
        }

    def _extract_attachments(self, payload: dict) -> list[dict[str, Any]]:
        attachments = []
        for part in self._iter_parts(payload):
            if part.get("filename"):
                attachments.append(
                    {
                        "filename": part["filename"],
                        "mime_type": part.get("mimeType", ""),
                        "size": part.get("body", {}).get("size", 0),
                    }
                )
        return attachments

    @classmethod
    def _iter_parts(cls, payload: dict):
        """Yield every part in a payload tree (including the root)."""
        yield payload
        for part in payload.get("parts", []):
            yield from cls._iter_parts(part)

    def _extract_body(self, payload: dict) -> str:
        """Return the plain-text body (preferred) or stripped HTML."""
        plain = ""
        html = ""
        for part in self._iter_parts(payload):
            mime = part.get("mimeType", "")
            data = part.get("body", {}).get("data", "")
            if mime == "text/plain" and not plain:
                plain = self._decode_base64(data)
            elif mime == "text/html" and not html:
                html = self._decode_base64(data)
        if plain:
            return plain
        if html:
            return self._strip_html(html)
        return ""

    @staticmethod
    def _decode_base64(data: str) -> str:
        if not data:
            return ""
        try:
            return base64.urlsafe_b64decode(data).decode("utf-8", errors="replace")
        except Exception:
            return ""

    @staticmethod
    def _strip_html(html: str) -> str:
        clean = re.sub(r"<(script|style)[^>]*>.*?</\1>", " ", html, flags=re.DOTALL | re.IGNORECASE)
        clean = re.sub(r"<[^>]+>", " ", clean)
        clean = re.sub(r"\s+", " ", clean).strip()
        return clean[:5000]
