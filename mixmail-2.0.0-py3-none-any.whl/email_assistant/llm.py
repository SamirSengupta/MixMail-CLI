"""LLM provider layer for MixMail.

A single :class:`LLMClient` talks to any **OpenAI-compatible** Chat Completions
endpoint. That covers:

* Local servers — LM Studio, llama.cpp, Ollama (``/v1``), vLLM, etc.
* Hosted providers — OpenAI, Groq, Together, Fireworks, OpenRouter, DeepInfra…
* Anthropic Claude / Google Gemini *via* an OpenAI-compatible gateway such as
  OpenRouter (set ``base_url`` to the gateway and ``model`` to e.g.
  ``anthropic/claude-3.5-sonnet``).

The client supports both blocking completions (used while the agent decides
which tools to call) and token streaming (used to render the final answer
live). Only the standard library is required — no extra dependencies.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Callable, Iterable
from urllib import error, request


class LLMError(RuntimeError):
    """Raised when the LLM endpoint is unreachable or returns an error."""


@dataclass
class LLMClient:
    """Minimal client for OpenAI-compatible Chat Completions endpoints."""

    base_url: str
    model: str
    api_key: str = ""
    extra_headers: dict[str, str] = field(default_factory=dict)
    timeout: int = 120

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    def complete(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        *,
        temperature: float = 0.2,
        tool_choice: str = "auto",
    ) -> dict[str, Any]:
        """Return the assistant message dict (OpenAI shape) for ``messages``."""
        payload = self._payload(messages, tools, temperature, tool_choice)
        payload["stream"] = False
        data = self._post_json(payload)
        return self._extract_message(data)

    def stream_complete(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        *,
        temperature: float = 0.2,
        tool_choice: str = "auto",
        on_delta: Callable[[str], None] | None = None,
    ) -> dict[str, Any]:
        """Stream a completion, returning the fully assembled message dict.

        ``on_delta`` is called with each text chunk as it arrives so callers
        can render output live. Tool-call fragments are accumulated and
        returned in the final message just like :meth:`complete`.
        """
        payload = self._payload(messages, tools, temperature, tool_choice)
        payload["stream"] = True
        req = self._build_request(payload)
        try:
            with request.urlopen(req, timeout=self.timeout) as response:
                return assemble_stream(_iter_sse(response), on_delta)
        except error.HTTPError as exc:  # pragma: no cover - network path
            body = exc.read().decode("utf-8", errors="replace")
            raise LLMError(
                f"LLM request failed with HTTP {exc.code}: {body}"
            ) from exc
        except error.URLError as exc:  # pragma: no cover - network path
            raise LLMError(
                f"Could not reach LLM server at {self.base_url}: {exc.reason}"
            ) from exc

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------
    def _payload(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None,
        temperature: float,
        tool_choice: str,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "model": self.model,
            "messages": messages,
            "temperature": temperature,
        }
        if tools:
            payload["tools"] = tools
            payload["tool_choice"] = tool_choice
        return payload

    def _headers(self) -> dict[str, str]:
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        headers.update(self.extra_headers)
        return headers

    def _build_request(self, payload: dict[str, Any]) -> request.Request:
        return request.Request(
            url=f"{self.base_url}/chat/completions",
            data=json.dumps(payload).encode("utf-8"),
            headers=self._headers(),
            method="POST",
        )

    def _post_json(self, payload: dict[str, Any]) -> dict[str, Any]:
        req = self._build_request(payload)
        try:
            with request.urlopen(req, timeout=self.timeout) as response:
                return json.loads(response.read().decode("utf-8"))
        except error.HTTPError as exc:
            body = exc.read().decode("utf-8", errors="replace")
            raise LLMError(
                f"LLM request failed with HTTP {exc.code}: {body}"
            ) from exc
        except error.URLError as exc:
            raise LLMError(
                f"Could not reach LLM server at {self.base_url}: {exc.reason}"
            ) from exc

    @staticmethod
    def _extract_message(data: dict[str, Any]) -> dict[str, Any]:
        choices = data.get("choices")
        if not isinstance(choices, list) or not choices:
            raise LLMError(
                "LLM response did not include choices. "
                f"Server response: {json.dumps(data, ensure_ascii=False)[:500]}"
            )
        message = choices[0].get("message") if isinstance(choices[0], dict) else None
        if not isinstance(message, dict):
            raise LLMError(
                "LLM response did not include a valid message object. "
                f"Server response: {json.dumps(data, ensure_ascii=False)[:500]}"
            )
        return message


# ---------------------------------------------------------------------------
# Streaming helpers (pure functions — unit-tested without network access)
# ---------------------------------------------------------------------------
def _iter_sse(response: Iterable[bytes]) -> Iterable[str]:
    """Yield decoded ``data:`` payloads from a Server-Sent Events stream."""
    for raw in response:
        line = raw.decode("utf-8", errors="replace").strip()
        if not line or not line.startswith("data:"):
            continue
        yield line[len("data:"):].strip()


def assemble_stream(
    data_chunks: Iterable[str],
    on_delta: Callable[[str], None] | None = None,
) -> dict[str, Any]:
    """Assemble streamed SSE ``data:`` chunks into a single message dict.

    Handles both content deltas and incremental ``tool_calls`` fragments
    (keyed by their ``index``), mirroring the OpenAI streaming format.
    """
    content_parts: list[str] = []
    tool_calls: dict[int, dict[str, Any]] = {}

    for chunk in data_chunks:
        if chunk == "[DONE]":
            break
        try:
            parsed = json.loads(chunk)
        except json.JSONDecodeError:
            continue

        choices = parsed.get("choices")
        if not isinstance(choices, list) or not choices:
            continue
        delta = choices[0].get("delta") or {}

        text = delta.get("content")
        if text:
            content_parts.append(text)
            if on_delta is not None:
                on_delta(text)

        for tc in delta.get("tool_calls") or []:
            index = tc.get("index", 0)
            slot = tool_calls.setdefault(
                index,
                {"id": "", "type": "function",
                 "function": {"name": "", "arguments": ""}},
            )
            if tc.get("id"):
                slot["id"] = tc["id"]
            fn = tc.get("function") or {}
            if fn.get("name"):
                slot["function"]["name"] += fn["name"]
            if fn.get("arguments"):
                slot["function"]["arguments"] += fn["arguments"]

    message: dict[str, Any] = {
        "role": "assistant",
        "content": "".join(content_parts),
    }
    if tool_calls:
        message["tool_calls"] = [tool_calls[i] for i in sorted(tool_calls)]
    return message
