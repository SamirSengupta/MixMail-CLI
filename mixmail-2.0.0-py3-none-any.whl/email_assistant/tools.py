"""Agent tools for MixMail.

Each tool wraps a :class:`GmailClient` method and returns JSON-serialisable
data. ``TOOL_SCHEMAS`` provides OpenAI-compatible function-calling descriptors,
and ``CONFIRM_TOOLS`` lists the actions that should be confirmed by the user
before they run (sending, replying, trashing).
"""

from __future__ import annotations

import json
from collections.abc import Callable
from typing import Any, cast

from email_assistant.gmail_client import GmailClient

_gmail: GmailClient | None = None


def _client() -> GmailClient:
    global _gmail  # noqa: PLW0603
    if _gmail is None:
        _gmail = GmailClient()
    return _gmail


def reset_client() -> None:
    """Drop the cached Gmail client (used after a scope/credential change)."""
    global _gmail  # noqa: PLW0603
    _gmail = None


# ===========================================================================
# Tool implementations
# ===========================================================================
def search_emails(query: str, max_results: int = 10) -> list[dict[str, Any]]:
    return _client().search_messages(query, max_results=max_results)


def get_email(message_id: str) -> dict[str, Any] | None:
    return _client().get_message_full(message_id)


def get_thread(thread_id: str) -> list[dict[str, Any]]:
    return _client().get_thread(thread_id)


def list_labels() -> list[dict[str, str]]:
    return _client().list_labels()


def send_email(to: str, subject: str, body: str, cc: str = "", bcc: str = "") -> dict[str, Any]:
    return _client().send_message(to=to, subject=subject, body=body, cc=cc, bcc=bcc)


def create_draft(to: str, subject: str, body: str, cc: str = "", bcc: str = "") -> dict[str, Any]:
    return _client().create_draft(to=to, subject=subject, body=body, cc=cc, bcc=bcc)


def reply(message_id: str, body: str, reply_all: bool = False) -> dict[str, Any]:
    return _client().reply(message_id, body, reply_all=reply_all)


def mark_read(message_id: str, read: bool = True) -> dict[str, Any]:
    return _client().mark_read(message_id, read=read)


def star_email(message_id: str, starred: bool = True) -> dict[str, Any]:
    return _client().set_starred(message_id, starred=starred)


def archive_email(message_id: str) -> dict[str, Any]:
    return _client().archive(message_id)


def trash_email(message_id: str) -> dict[str, Any]:
    return _client().trash(message_id)


def download_attachment(message_id: str, filename: str, save_dir: str = ".") -> dict[str, Any]:
    return _client().download_attachment(message_id, filename, save_dir)


# ===========================================================================
# OpenAI function-calling schemas
# ===========================================================================
def _schema(name: str, description: str, properties: dict, required: list[str]) -> dict:
    return {
        "type": "function",
        "function": {
            "name": name,
            "description": description,
            "parameters": {"type": "object", "properties": properties, "required": required},
        },
    }


TOOL_SCHEMAS: list[dict[str, Any]] = [
    _schema(
        "search_emails",
        "Search the user's Gmail using Gmail search syntax. Translate natural "
        "language into operators: from:, to:, subject:, newer_than:Nd, "
        "older_than:Nd, is:unread, has:attachment, label:, in:inbox, in:sent, "
        "category:. Example: 'from:amazon newer_than:7d'.",
        {
            "query": {"type": "string", "description": "Gmail search query."},
            "max_results": {"type": "integer", "description": "Max emails to return (default 10)."},
        },
        ["query"],
    ),
    _schema(
        "get_email",
        "Fetch the full content (body + attachments) of one email by message ID. "
        "Use when the user wants to read an email or you need the body to summarise.",
        {"message_id": {"type": "string", "description": "Gmail message ID."}},
        ["message_id"],
    ),
    _schema(
        "get_thread",
        "Fetch every message in a conversation thread. Use to summarise a whole "
        "email conversation.",
        {"thread_id": {"type": "string", "description": "Gmail thread ID."}},
        ["thread_id"],
    ),
    _schema(
        "list_labels",
        "List the user's Gmail labels (id and name).",
        {},
        [],
    ),
    _schema(
        "send_email",
        "Send an email from the authenticated account. Only call when the user "
        "clearly asked to send and the recipient, subject, and body are known.",
        {
            "to": {"type": "string", "description": "Recipient(s), comma-separated."},
            "subject": {"type": "string", "description": "Subject line."},
            "body": {"type": "string", "description": "Plain-text body."},
            "cc": {"type": "string", "description": "Optional CC list."},
            "bcc": {"type": "string", "description": "Optional BCC list."},
        },
        ["to", "subject", "body"],
    ),
    _schema(
        "create_draft",
        "Create a draft email without sending it. Use when the user wants to "
        "prepare or review a message before sending.",
        {
            "to": {"type": "string", "description": "Recipient(s), comma-separated."},
            "subject": {"type": "string", "description": "Subject line."},
            "body": {"type": "string", "description": "Plain-text body."},
            "cc": {"type": "string", "description": "Optional CC list."},
            "bcc": {"type": "string", "description": "Optional BCC list."},
        },
        ["to", "subject", "body"],
    ),
    _schema(
        "reply",
        "Reply to an existing email, preserving the thread. Provide the body; "
        "set reply_all to include everyone on the original.",
        {
            "message_id": {"type": "string", "description": "Message ID to reply to."},
            "body": {"type": "string", "description": "Plain-text reply body."},
            "reply_all": {"type": "boolean", "description": "Reply to all recipients."},
        },
        ["message_id", "body"],
    ),
    _schema(
        "mark_read",
        "Mark a message read or unread.",
        {
            "message_id": {"type": "string", "description": "Gmail message ID."},
            "read": {"type": "boolean", "description": "True to mark read, False for unread."},
        },
        ["message_id"],
    ),
    _schema(
        "star_email",
        "Star or unstar a message.",
        {
            "message_id": {"type": "string", "description": "Gmail message ID."},
            "starred": {"type": "boolean", "description": "True to star, False to unstar."},
        },
        ["message_id"],
    ),
    _schema(
        "archive_email",
        "Archive a message (remove it from the inbox without deleting).",
        {"message_id": {"type": "string", "description": "Gmail message ID."}},
        ["message_id"],
    ),
    _schema(
        "trash_email",
        "Move a message to Trash. Reversible for about 30 days.",
        {"message_id": {"type": "string", "description": "Gmail message ID."}},
        ["message_id"],
    ),
    _schema(
        "download_attachment",
        "Download a named attachment from a message to a local folder.",
        {
            "message_id": {"type": "string", "description": "Gmail message ID."},
            "filename": {"type": "string", "description": "Exact attachment filename."},
            "save_dir": {"type": "string", "description": "Destination folder (default current)."},
        },
        ["message_id", "filename"],
    ),
]

TOOL_DISPATCH: dict[str, Callable[..., Any]] = {
    "search_emails": search_emails,
    "get_email": get_email,
    "get_thread": get_thread,
    "list_labels": list_labels,
    "send_email": send_email,
    "create_draft": create_draft,
    "reply": reply,
    "mark_read": mark_read,
    "star_email": star_email,
    "archive_email": archive_email,
    "trash_email": trash_email,
    "download_attachment": download_attachment,
}

# Tools that should be confirmed by the user before running.
CONFIRM_TOOLS: frozenset[str] = frozenset({"send_email", "reply", "trash_email"})


def describe_tool_call(name: str, arguments: dict[str, Any]) -> str:
    """Return a short human-readable description of a pending tool call."""
    if name == "send_email":
        return (
            f"Send email to {arguments.get('to', '?')}"
            + (f", cc {arguments['cc']}" if arguments.get("cc") else "")
            + f"\nSubject: {arguments.get('subject', '')}\n\n{arguments.get('body', '')}"
        )
    if name == "reply":
        scope = "all recipients" if arguments.get("reply_all") else "the sender"
        return f"Reply to {scope} of message {arguments.get('message_id', '?')}:\n\n{arguments.get('body', '')}"
    if name == "trash_email":
        return f"Move message {arguments.get('message_id', '?')} to Trash."
    return f"{name}({json.dumps(arguments, ensure_ascii=False)})"


def execute_tool(name: str, arguments: object) -> str:
    """Execute a tool by name and return a JSON string result."""
    if isinstance(arguments, str):
        try:
            arguments = json.loads(arguments) if arguments.strip() else {}
        except json.JSONDecodeError as exc:
            return json.dumps({"error": f"Invalid tool arguments: {exc}"})
    if not isinstance(arguments, dict):
        return json.dumps({"error": "Tool arguments must be a JSON object."})

    func = TOOL_DISPATCH.get(name)
    if func is None:
        return json.dumps({"error": f"Unknown tool: {name}"})

    try:
        result = func(**cast(dict[str, Any], arguments))
        return json.dumps(result, default=str, ensure_ascii=False)
    except Exception as exc:  # noqa: BLE001
        return json.dumps({"error": str(exc)})
