"""Unit tests for MixMail's pure logic.

Run with either:

    python -m unittest discover -s tests
    pytest

The tests stub out the Google API client and rich so they run without those
packages installed, and never touch your real Gmail or ``.env``.
"""

from __future__ import annotations

import json
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _stubs  # noqa: E402,F401  (installs stubs + temp config home)

from email_assistant import agent as agent_mod  # noqa: E402
from email_assistant import config, tools  # noqa: E402
from email_assistant.gmail_client import GmailClient  # noqa: E402
from email_assistant.llm import assemble_stream  # noqa: E402


# ---------------------------------------------------------------------------
# Streaming
# ---------------------------------------------------------------------------
class StreamAssemblyTests(unittest.TestCase):
    def _chunks(self, *objs):
        return [json.dumps(o) for o in objs]

    def test_content_deltas_concatenate_and_emit(self):
        seen = []
        chunks = self._chunks(
            {"choices": [{"delta": {"content": "Hel"}}]},
            {"choices": [{"delta": {"content": "lo!"}}]},
        ) + ["[DONE]"]
        msg = assemble_stream(chunks, on_delta=seen.append)
        self.assertEqual(msg["content"], "Hello!")
        self.assertEqual(seen, ["Hel", "lo!"])
        self.assertNotIn("tool_calls", msg)

    def test_tool_call_fragments_accumulate_by_index(self):
        chunks = self._chunks(
            {"choices": [{"delta": {"tool_calls": [
                {"index": 0, "id": "call_1",
                 "function": {"name": "search_", "arguments": '{"que'}}]}}]},
            {"choices": [{"delta": {"tool_calls": [
                {"index": 0, "function": {"name": "emails", "arguments": 'ry":"hi"}'}}]}}]},
        )
        msg = assemble_stream(chunks)
        self.assertEqual(len(msg["tool_calls"]), 1)
        call = msg["tool_calls"][0]
        self.assertEqual(call["id"], "call_1")
        self.assertEqual(call["function"]["name"], "search_emails")
        self.assertEqual(json.loads(call["function"]["arguments"]), {"query": "hi"})

    def test_malformed_chunks_are_skipped(self):
        msg = assemble_stream(["not json", '{"choices": []}', "[DONE]"])
        self.assertEqual(msg["content"], "")


# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------
class ConfigUrlTests(unittest.TestCase):
    def test_strips_chat_completions_suffix(self):
        self.assertEqual(
            config._normalise_llm_base_url("http://localhost:1200/v1/chat/completions"),
            "http://localhost:1200/v1",
        )

    def test_trailing_slash_removed(self):
        self.assertEqual(
            config._normalise_llm_base_url("http://localhost:1200/v1/"),
            "http://localhost:1200/v1",
        )

    def test_requires_scheme(self):
        with self.assertRaises(ValueError):
            config._normalise_llm_base_url("localhost:1200/v1")

    def test_rejects_nested_chat_path(self):
        with self.assertRaises(ValueError):
            config._normalise_llm_base_url("http://localhost/v1/chat/foo")


class ScopeTests(unittest.TestCase):
    def test_readonly_is_default_and_not_writable(self):
        s = config.Settings(gmail_scope_mode="readonly")
        self.assertFalse(s.can_write)
        self.assertEqual(s.gmail_scopes, config.GMAIL_SCOPE_PRESETS["readonly"])

    def test_full_mode_is_writable(self):
        s = config.Settings(gmail_scope_mode="full")
        self.assertTrue(s.can_write)
        self.assertIn(
            "https://www.googleapis.com/auth/gmail.send", s.gmail_scopes
        )

    def test_unknown_mode_falls_back_to_readonly(self):
        s = config.Settings(gmail_scope_mode="bogus")
        self.assertEqual(s.gmail_scopes, config.GMAIL_SCOPE_PRESETS["readonly"])


class EnvWriteTests(unittest.TestCase):
    def setUp(self):
        self._cwd = os.getcwd()
        self._tmp = tempfile.mkdtemp(prefix="mixmail-env-")
        os.chdir(self._tmp)  # no .env here -> writes go to MIXMAIL_HOME

    def tearDown(self):
        os.chdir(self._cwd)

    def test_save_model_roundtrips(self):
        config.save_llm_model("my-model")
        self.assertEqual(os.environ["LLM_MODEL"], "my-model")
        self.assertEqual(config.get_settings().llm_model, "my-model")

    def test_save_scope_mode_validates(self):
        with self.assertRaises(ValueError):
            config.save_gmail_scope_mode("nonsense")


# ---------------------------------------------------------------------------
# Gmail parsing helpers
# ---------------------------------------------------------------------------
class GmailParsingTests(unittest.TestCase):
    def setUp(self):
        self.client = GmailClient.__new__(GmailClient)  # no __init__/auth

    def test_parse_message_extracts_headers_and_attachments(self):
        msg = {
            "id": "m1",
            "threadId": "t1",
            "snippet": "hi there",
            "labelIds": ["INBOX", "UNREAD"],
            "payload": {
                "headers": [
                    {"name": "From", "value": "Alice <a@x.com>"},
                    {"name": "Subject", "value": "Hello"},
                    {"name": "Date", "value": "Mon, 16 Jun 2025 10:00:00 +0000"},
                ],
                "parts": [
                    {"mimeType": "text/plain", "body": {}},
                    {"filename": "report.pdf", "mimeType": "application/pdf", "body": {"size": 12}},
                ],
            },
        }
        parsed = self.client._parse_message(msg)
        self.assertEqual(parsed["sender"], "Alice <a@x.com>")
        self.assertEqual(parsed["subject"], "Hello")
        self.assertTrue(parsed["has_attachments"])
        self.assertEqual(parsed["attachment_names"], ["report.pdf"])
        self.assertTrue(parsed["date"].startswith("2025-06-16"))

    def test_extract_body_prefers_plain_text(self):
        import base64

        def enc(s):
            return base64.urlsafe_b64encode(s.encode()).decode()

        payload = {
            "parts": [
                {"mimeType": "text/plain", "body": {"data": enc("plain wins")}},
                {"mimeType": "text/html", "body": {"data": enc("<b>nope</b>")}},
            ]
        }
        self.assertEqual(self.client._extract_body(payload), "plain wins")

    def test_strip_html_removes_tags_and_scripts(self):
        html = "<script>evil()</script><p>Hello <b>world</b></p>"
        self.assertEqual(self.client._strip_html(html), "Hello world")


# ---------------------------------------------------------------------------
# Tools dispatch
# ---------------------------------------------------------------------------
class FakeClient:
    def __init__(self):
        self.calls = []

    def search_messages(self, query, max_results=10):
        self.calls.append(("search", query, max_results))
        return [{"subject": "Test", "sender": "x@y.com"}]


class ToolDispatchTests(unittest.TestCase):
    def setUp(self):
        self.fake = FakeClient()
        tools._gmail = self.fake  # inject fake client

    def tearDown(self):
        tools.reset_client()

    def test_search_emails_dispatch(self):
        out = json.loads(tools.execute_tool("search_emails", {"query": "from:x", "max_results": 3}))
        self.assertEqual(out[0]["subject"], "Test")
        self.assertEqual(self.fake.calls[0], ("search", "from:x", 3))

    def test_unknown_tool_returns_error(self):
        out = json.loads(tools.execute_tool("nope", {}))
        self.assertIn("Unknown tool", out["error"])

    def test_invalid_json_arguments(self):
        out = json.loads(tools.execute_tool("search_emails", "{bad json"))
        self.assertIn("error", out)

    def test_confirm_tools_membership(self):
        self.assertEqual(
            set(tools.CONFIRM_TOOLS), {"send_email", "reply", "trash_email"}
        )

    def test_describe_send_includes_recipient_and_subject(self):
        desc = tools.describe_tool_call(
            "send_email", {"to": "a@b.com", "subject": "Hi", "body": "Yo"}
        )
        self.assertIn("a@b.com", desc)
        self.assertIn("Hi", desc)


# ---------------------------------------------------------------------------
# Agent loop
# ---------------------------------------------------------------------------
class FakeLLM:
    """Returns scripted assistant messages on successive complete() calls."""

    def __init__(self, scripted):
        self.scripted = list(scripted)
        self.calls = 0

    def complete(self, messages, tools=None, **kw):
        msg = self.scripted[self.calls]
        self.calls += 1
        return msg

    def stream_complete(self, messages, tools=None, on_delta=None, **kw):
        msg = self.complete(messages, tools, **kw)
        if on_delta and msg.get("content"):
            on_delta(msg["content"])
        return msg


class FakeSettings:
    system_prompt = "system"

    def __init__(self, llm):
        self._llm = llm

    def validate(self):
        pass

    def llm_client(self):
        return self._llm


def _tool_call(call_id, name, args):
    return {
        "role": "assistant",
        "content": "",
        "tool_calls": [
            {"id": call_id, "type": "function",
             "function": {"name": name, "arguments": json.dumps(args)}}
        ],
    }


class AgentLoopTests(unittest.TestCase):
    def tearDown(self):
        agent_mod.execute_tool = _ORIGINAL_EXECUTE

    def test_tool_then_final_answer(self):
        executed = []

        def fake_execute(name, arguments):
            executed.append((name, arguments))
            return json.dumps([{"subject": "Found"}])

        agent_mod.execute_tool = fake_execute

        llm = FakeLLM([
            _tool_call("c1", "search_emails", {"query": "is:unread"}),
            {"role": "assistant", "content": "You have 1 unread email."},
        ])
        ag = agent_mod.EmailAgent(settings=FakeSettings(llm))
        answer = ag.ask("any unread?")
        self.assertEqual(answer, "You have 1 unread email.")
        self.assertEqual(executed[0][0], "search_emails")

    def test_declined_confirmation_skips_execution(self):
        executed = []

        def fake_execute(name, arguments):
            executed.append(name)
            return json.dumps({"status": "sent"})

        agent_mod.execute_tool = fake_execute

        llm = FakeLLM([
            _tool_call("c1", "send_email",
                       {"to": "a@b.com", "subject": "Hi", "body": "Yo"}),
            {"role": "assistant", "content": "Okay, I won't send it."},
        ])
        ag = agent_mod.EmailAgent(
            settings=FakeSettings(llm),
            confirm_callback=lambda name, desc: False,  # decline
        )
        answer = ag.ask("send a@b.com hi")
        self.assertEqual(answer, "Okay, I won't send it.")
        self.assertNotIn("send_email", executed)  # never executed

    def test_reset_keeps_system_prompts(self):
        llm = FakeLLM([{"role": "assistant", "content": "hi"}])
        ag = agent_mod.EmailAgent(settings=FakeSettings(llm))
        ag.ask("hello")
        ag.reset()
        self.assertEqual(len(ag._conversation), 2)  # two system messages
        self.assertTrue(all(m["role"] == "system" for m in ag._conversation))


_ORIGINAL_EXECUTE = agent_mod.execute_tool


if __name__ == "__main__":
    unittest.main(verbosity=2)
